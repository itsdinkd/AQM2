// Another Quality Modpack 2 //
//////////////////////////////
REIEvents.hide('item', (event) => { 

  event.hide(Item.of('quarryplus:adv_quarry'));
})