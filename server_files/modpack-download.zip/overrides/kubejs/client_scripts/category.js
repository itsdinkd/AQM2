// //Another Quality Modpack 2


// REIEvents.removeCategories(event => {
//     event.yeet('twilightforest:uncrafting')
//   })