ClientEvents.leftDebugInfo(event => {
    let lines = event.getLines()
    lines.addAll([
        '--------------------------',
        'Another Quality Modpack 2',
        'Created by diNkd         ',
        '--------------------------'
    ])
});